1, make all
   
   
   gcc -c testdriver.c -o testdriver.o
   gcc -c test.c -o test.o
   gcc testdriver.o test.o -o test

2, ./test

