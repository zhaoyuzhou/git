/**************************************************************************************************/
/* Copyright (C) SSE@USTC, 2014-2015                                                              */
/*                                                                                                */
/*  FILE NAME             :  teststub.h                                                           */
/*  PRINCIPAL AUTHOR      :  zhouzhaoyu                                                           */
/*  SUBSYSTEM NAME        :  testdriver                                                           */
/*  MODULE NAME           :  testdriver                                                           */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/29                                                           */
/*  DESCRIPTION           :  interface of test.c                                                  */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by zhouzhaoyu, 2014/09/29
 *
 */

#define SUCCESS 0
#define FAILURE 1


typedef struct TestStubNode
{
    struct TestStubNode * pNext;
}tTestStubNode;

typedef struct TestStub tTestStub;
int DeleteTestStub(tTestStub *pTestStub);
/*
* Delete a LinkTable
*/
int AddTestStubNode(tTestStub *pTestStub,tTestStubNode * pNode);
/*
* Add a LinkTableNode to LinkTable
*/
int DelTestStubNode(tTestStub *pTestStub,tTestStubNode * pNode); 
/*
* Delete a LinkTableNode from LinkTable
*/

