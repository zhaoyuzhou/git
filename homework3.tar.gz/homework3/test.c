/**************************************************************************************************/
/* Copyright (C) SSE@USTC, 2014-2015                                                              */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  zhouzhaoyu                                                           */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/29                                                           */
/*  DESCRIPTION           :   test.c                                                              */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by zhouzhaoyu, 2014/09/29
 *
 */
#include<stdio.h>
#include"teststub.h"

#define debug

int results[4] = {1,1,1,1};
char * info[4] =
{
    "test report",
    "TC1 DeleteTestStub",
    "TC2 AddTestStubNode",
    "TC3 DelTestStubNode" 
};

int main()
{   
    int j;
    tTestStub * p=NULL;
    int ret =DeleteTestStub(p);
    if(ret == SUCCESS)
    {
        debug("TC1 Success\n");
        results[1] = 0;
    }
    
    tTestStubNode * pNode = NULL;
    int rec = AddTestStubNode(p,pNode);
    if(rec == SUCCESS)
    {
        debug("TC2 Success\n");
        results[2] = 0;
    }

    int rea = DelTestStubNode(p,pNode);
    if(rea == FAILURE)
    {
        debug("TC3 Failure\n");
        results[3] = 1;
    }
    /* more test case ...*/
    /* test report */
    printf("test report\n");
    for(j=1;j<=3;j++)
    {
        if(results[j] == 1)
        {
            printf("Testcase Number%d  - %s\n",j,info[j]);
        }
    }
}
