/**************************************************************************************************/
/* Copyright (C) SSE@USTC, 2014-2015                                                              */
/*                                                                                                */
/*  FILE NAME             :  testdriver.c                                                         */
/*  PRINCIPAL AUTHOR      :  zhouzhaoyu                                                           */
/*  SUBSYSTEM NAME        :  testdriver                                                           */
/*  MODULE NAME           :  testdriver                                                           */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/29                                                           */
/*  DESCRIPTION           :  testdriver.c                                                         */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by zhouzhaoyu, 2014/09/29
 *
 */
#include<stdio.h>
#include"teststub.h"
int DeleteTestStub(tTestStub *pTestStub)
{
    if(pTestStub == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}


int AddTestStubNode(tTestStub *pTestStub,tTestStubNode * pNode)
{
    if(pTestStub == NULL || pNode == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}

int DelTestStubNode(tTestStub *pTestStub,tTestStubNode * pNode)
{
    if(pTestStub != NULL || pNode != NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}


